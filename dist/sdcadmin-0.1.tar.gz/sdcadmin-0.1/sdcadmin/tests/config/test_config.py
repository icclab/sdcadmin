__author__ = 'ernm'


class TestConfig(object):
    # @hn:
    # for service in sapi vmapi fwapi imgapi napi papi workflow;
    # do
    #   vmadm get $( sdc-vmname $service ) | json nics.0.ip
    # done
    sapi_ip = '10.0.0.26'
    vmapi_ip = '10.0.0.21'
    fwapi_ip = '10.0.0.20'
    imgapi_ip = '10.0.0.15'
    napi_ip = '10.0.0.4'
    papi_ip = '10.0.0.23'
    workflow_ip = '10.0.0.13'

    #@adminui: manual retrieval
    user_uuid = 'ca50e0a6-0f87-c911-fb01-e139514f760f'
    package_small = 'a8c2033d-e8eb-c17e-83ce-b10e36f1339b'
    package_big = '395ecfd6-3050-4082-ea25-9b51ad72873d'
    smartmachine_image = '859e9466-7ef4-11e4-b103-27886e7d9a7d'
    kvm_image = 'b1df4936-7a5c-11e4-98ed-dfe1fa3a813a'
    network_uuid = 'f27c02f1-5b4c-4ef1-b463-59c7e60f02e5'

