__author__ = 'ernm'


class Job(object):
    uuid = ''
    workflow = ''
    workflow_uuid = ''

    def __init__(self, datacenter, data=None, uuid=None):

        self.dc = datacenter

        if not data:
            if not uuid:
                raise ValueError('Must provide either data or uuid')
            data, _ = self.dc.request('GET', 'workflow', '/jobs/' + uuid)
        self._save(data)

    def _save(self, data):
        for k, v in data.iteritems():
            setattr(self, k, v)

    def __eq__(self, other):
        if isinstance(other, Job):
            return self.uuid == other.uuid
        return False