from distutils.core import setup

setup(
    name='sdcadmin',
    version='0.1',
    packages=['sdcadmin', 'sdcadmin.tests', 'sdcadmin.tests.config'],
    url='https://github.com/icclab/sdcadmin',
    license='Apache License, Version 2.0',
    author='ernm',
    author_email='ernm@zhaw.ch',
    description='API wrapper for the SDC APIs on the admin network'
)
